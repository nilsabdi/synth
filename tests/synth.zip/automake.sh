#!/bin/bash

while inotifywait -q -e modify . ; do
	clear && clear
	lua parser.lua
done
