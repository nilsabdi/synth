require "template"

return template {} {
   segment {"parse", entry = "program", ignore = {T"space", T"newline"}} {
      program = {[[ expr:add ]]},
      term = {[[ term:NUMBER ]]},
      add = {[[ left:term right:addr ]]},
      addr = {
         {add = [[ '+' right:term next:addr ]]},
         {sub = [[ '-' right:term next:addr ]]},
         {adde = [[ '+' right:term ]]},
         {sube = [[ '-' right:term ]]}
      }
   },
   segment {"script", direction = "up"} {
      add = function (node)
         node.right.left = node.left
         node.left = nil
         print('in', dump(node, nil, true))
      end;

      addr = {
         add = function (node)
            node.next.left = node.right
            node.right = nil
            print('in', dump(node, nil, true))
         end;

         sub = function (node)
            node.next.left = node.right
            node.right = nil
            print('in', dump(node, nil, true))
         end;
      }
   },
   segment {"output"} {
      program = [[ expr ]],
      term = [[ term ]],
      add = [[ right ]],
      addr = {
         add = [[ '(add ' left ' ' next ')']],
         sub = [[ '(sub ' left ' ' next ')']],
         adde = [[ '(add ' left ' ' right ')']],
         sube = [[ '(sub ' left ' ' right ')']]
      }
   }
}
