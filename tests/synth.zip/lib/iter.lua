function collect(iter)
   local items = {}
   local k, v = iter()
   while k ~= nil do
      items[k] = v
      k, v = iter()
   end
   return items
end

function filter(array, condition)
   assert(type(array) == "table", "can only filter tables")
   local new = {}
   for i, v in pairs(array) do
      if condition(i, v) then
         new[#new + 1] = v
      end
   end
   return new
end

function map(array, func)
   assert(type(array) == "table", "can only map tables")
   for i, v in pairs(array) do
      local ret = func(v)
      if ret then
         array[i] = ret
      end
   end
end

function iter(array)
   assert(type(array) == "table", "can only iter tables")
   local iter = {}
   local __iter__ = {curr = 1, last = 1}
   __iter__.__iter__ = __iter__

   for k, v in pairs(array) do
      iter[k] = v
   end

   __iter__.collect = collect
   __iter__.filter = filter
   __iter__.map = map

   function __iter__:next()
      self.__iter__.last = self.__iter__.curr > self.__iter__.last and self.__iter__.curr or self.__iter__.last
      self.__iter__.curr = self.__iter__.curr + 1
      return self[self.__iter__.curr - 1]
   end
   function __iter__:peek()
      return self[self.__iter__.curr]
   end
   function __iter__:getpos()
      return self.__iter__.curr
   end
   function __iter__:getlast()
      return self.__iter__.last
   end
   function __iter__:setpos(n)
      self.__iter__.curr = n
      self.__iter__.last = self.__iter__.curr > self.__iter__.last and self.__iter__.curr or self.__iter__.last
   end

   function __iter__:count()
      local count = 0
      for k, v in pairs(self) do
         count = count + 1
      end
      return count
   end

   return setmetatable(
      iter,
      {
         __call = function(self)
            self.__iter__.last = self.__iter__.curr > self.__iter__.last and self.__iter__.curr or self.__iter__.last
            self.__iter__.curr = self.__iter__.curr + 1
            return self[self.__iter__.curr - 1]
         end,
         __index = __iter__
      }
   )
end
