require "tokenizer"

local temp = require "hello"
local __debug__ = true

--[[
   operators
      e?  - one or none
      e*  - none or more
      e+  - one or more
      e!  - all but e
      r.v - rule.variant
      a:e - alias:element
]]
local _iter = iter

function meta(node)
   return getmetatable(node)
end

function errfmt(token)
   dprint(dump(token))
   local line = token.meta.source
   local before = line {0, token.pos.from} :split "\n"
   local after = line {token.pos.to, 0} :split "\n"
   return 
      "\n" .. ("%5d| "):format(token.pos.line)
      ..  before[#before] 
      .. "\27[41m" .. (token.type=='newline' and ' ' or token.lexeme) .. "\27[0m" 
      .. (token.type~='newline' and after[1] or '')
end

function findOrderedKey(table, key)
   for _, item in pairs(table) do
      if item[key] then
         return item[key]
      end
   end
end

function dprint(...)
   if __debug__ then
      io.write('['..debug.getinfo(2).short_src..'|'..debug.getinfo(2).currentline..'] ')
      print(...)
   end
end

function iter(tokens)
   local it = _iter(tokens)

   -- auto skip tokens
   it.__iter__.skip = {}

   it.inext = it.next
   it.ipeek = it.peek

   function it:next()
      while 0 <
         #filter(
            self.__iter__.skip,
            function(_, elem)
               return self:ipeek() and self:ipeek():eq(elem)
            end
         ) do
         self:inext()
      end
      return self:inext()
   end

   function it:peek()
      local save = self:getpos()
      while 0 <
         #filter(
            self.__iter__.skip,
            function(_, elem)
               return self:ipeek() and self:ipeek():eq(elem)
            end
         ) do
         self:inext()
      end
      local e = self:ipeek()
      self:setpos(save)
      return e
   end

   function it:get(off)
      return self[self.__iter__.curr + off]
   end

   function it:skip(...)
      while self:match(...) do
      end
      return self
   end

   function it:check(...)
      local save = self:getpos()
      local match = self:match(...)
      self:setpos(save)
      return match
   end

   function it:match(...)
      -- string for lexeme, {lexeme, T=string} for type and/or lexeme
      local save = self:getpos()

      for _, elem in pairs {...} do
         local tok = self:inext()
         if not tok then
            self:setpos(save)
            return false
         end
         --         print('<'..tostring(tok)..'>','==',dump(elem), "=", tok:eq(elem))

         while tok and not tok:eq(elem) do
            local skipped = false
            -- try skipping tokens
            for _, skip in pairs(self.__iter__.skip) do
               if tok:eq(skip) then
                  skipped = true
                  -- print("skipped", '<'..tostring(tok)..'> while matcing <'..dump(elem)..">")
                  tok = self:inext()
                  if not tok then
                     return false
                  end
                  break
               -- skipped, try matching again
               end
            end
            -- print('>'..tostring(self:ipeek())..'<',skipped, tok, dump({...}))
            -- token didn't match and nothing got skipped
            if not skipped then
               self:setpos(save)
               return false
            end
         end
      end
      -- print('>>'..tostring(self:ipeek())..'<<')
      return true
   end

   return it
end

-- process(tokens: table, template: table) -> table
function process(tokens, template)
   assert(tokens, "tokens required")
   assert(template, "language template required")

   tokens.__iter__.skip = template.ignore

   local ast
   local out = ""
   local entry

   for s, segment in pairs(template) do
      if segment.type == "parse" then
         dprint(">> parse")
         entry = assert(segment.entry, "parse segments need an entry point")

         local old_ignores = tokens.__iter__.skip
         -- dprint("old_ignores", dump(old_ignores))
         tokens.__iter__.skip = segment.ignore
         -- dprint("new_ignores", dump(tokens.__iter__.skip))

         for v, pattern in pairs(segment[segment.entry]) do
            dprint("parsing " .. v .. " " .. pattern)
            local iter = iter(collect(tokenize(pattern, {file = "template"})))
            ast = parse(tokens, segment, segment.entry, v, iter)
            if ast then
               dprint(dump(ast))
               setmetatable(ast, {type={segment.entry}})
               break
            end
         end

         if tokens:peek() then
            error('Unexpected token' .. errfmt(tokens[tokens:getlast()]))
         end

         tokens.__iter__.skip = old_ignores

         dprint(dump(ast))
      end

      if segment.type == "script" then
         dprint(">> script")
         assert(entry, "a parser segment is required with an entry point to have an AST to modify with scripts")
         script(segment, ast)
      end

      if segment.type == "output" then
         dprint(">> output")
         assert(entry, "a parser segment is required with an entry point to have anything to output")
         if type(segment[entry]) == "table" then
            for v, pattern in pairs(segment[entry]) do
               dprint("outputting " .. v .. " " .. pattern)
               local iter = iter(collect(tokenize(pattern, {file = "template"})))
               -- dprint(output(segment, ast, iter))
            end
         else
            local pattern = segment[entry]
            -- dprint("outputting " .. entry .. " " .. pattern)
            local iter = iter(collect(tokenize(pattern, {file = "template"})))
            out = out .. output(segment, ast, iter)
         end
      end
   end

   return out
end

function script(segment, ast)
   if segment.direction == 'up' then
      for alias, child in pairs(ast) do
         if meta(child).type then
            script(segment, child)

            local func = segment
            local typename = ""
            for _, t in ipairs(meta(child).type) do
               typename = typename .. t .. "."
               func = func[t]
            end
            if not func then
               print('no such func ' ..typename)
            else
               func(child)
            end
         end
      end
   end
end

function output(segment, ast, pattern)
   pattern.__iter__.skip = {T "space"}

   local elem = pattern:peek()
   local out = ""

   while elem do
      if pattern:check(T "word") then
         local alias = pattern:next().lexeme
         -- dprint("output: got alias", alias)
         local child = assert(ast[alias], "no such child '" .. alias .. "' in node " .. dump(meta(ast).type))

         if meta(child).type then
            local pattern = segment
            local typename = ""

            for _, t in ipairs(meta(child).type) do
               typename = typename .. t .. "."
               pattern = assert(pattern[t], "no such pattern " .. typename)
            end

            -- dprint(dump(pattern), ">>", dump(child))

            -- for i, child in ipairs(child) do
               local iter = iter(collect(tokenize(pattern, {file = "template"})))

               out = out .. assert(output(segment, child, iter), "error in " .. "{" .. pattern .. "}")
            -- end
         else
            out = out .. child
         end
      elseif pattern:check {T = "symbol", "'"} then
         -- dprint("checked", pattern:peek(), pattern:check {T = "symbol", "'"})
         out = out .. pstring(pattern)
      else
         local t = pattern:peek()
         -- error("pattern <" .. nrule .. "." .. nvariant .. "> stopped on token '" .. t .. "' at " .. t.pos.from)
      end

      elem = pattern:peek()
   end

   return out
end

-- parse(tokens:table, segment:segment, nrule:string, nvariant:string, pattern:table) -> table
function parse(tokens, segment, nrule, nvariant, pattern)
   pattern.__iter__.skip = {T "space"}

   local elem = pattern:peek()
   local node = {}
   local last_token = tokens:peek()

   local save = tokens:getpos()

   while elem do
      -- print(dump(elem))

      if pattern:check(T "word", {T = "symbol", ":"}) then
         local alias = pattern:next().lexeme

         pattern:skip(":")
         dprint("parse: aliased", alias)
         local s = ""
         for i = -2, 2 do
            s = s .. (i == 0 and "\27[41m" or "") .. (tokens:get(i) or "") .. (i == 0 and "\27[0m" or "")
         end

         local element = element(tokens, segment, nrule, nvariant, pattern)

         if not element then
            tokens:setpos(save)
            return
         end

         -- if type(element) == "table" then
         -- node.variant = nvariant
         -- end
         node[alias] = element
      elseif pattern:check {T = "symbol", "'"} then
         local st = pstring(pattern)
         if not tokens:match(st) then
            -- dprint("didn't match '" .. st .. "'")
            return
         -- else
         -- dprint("matched string '" .. st .. "'")
         end
      else
         local t = pattern:peek()
         error("pattern <" .. nrule .. "." .. nvariant .. "> stopped on token '" .. t .. "' at " .. t.pos.from)
      end

      elem = pattern:peek()
      if last_token == tokens:peek() then
         error("token iterator hasn't moved, probably a parse loop")
      end
   end

   return node
end

-- element(tokens:table, segment:segment, nrule:string, nvariant:string, pattern:table) -> table
function element(tokens, segment, nrule, nvariant, pattern)
   dprint(">>", pattern:peek())

   local rule
   local variant
   local tokentype
   local child_pattern
   local node
   local modifiers = {}
   local _type

   local allmods = {"?", "*", "+"}

   if pattern:check(T "word") then
      local item = pattern:next().lexeme
      if item:isupper() then
         tokentype = T(item)
         dprint("got tokentype: " .. dump(tokentype))
      else
         rule = item
         dprint("got rule: " .. rule)
         _type = {rule}
      end
   end

   if pattern:match {T = "symbol", "."} then
      assert(pattern:check(T "word"), "variant name must follow .")
      variant = pattern:next().lexeme
      dprint("got variant: " .. variant)
      _type = {_type[1], variant}
   end

   if not (rule or tokentype) and pattern:check {T = "symbol", "'"} then
      node = pstring(pattern)
   end

   while pattern:check(T "symbol") and not pattern:check "'" do
      -- dprint(pattern:check(T'symbol'))
      -- dprint('got modifier', pattern:peek())
      -- dprint(dump(modifiers))
      assert(
         #_iter(allmods):filter(
            function(_, e)
               return pattern:check {T = "symbol", e}
            end
         ) > 0,
         "unknown modifier `" .. tostring(pattern:peek()) .. "`"
      )

      local modifier = pattern:next().lexeme
      assert(not modifiers[modifier], "modifier `" .. modifier .. "` already specified")
      modifiers[modifier] = true
   end

   dprint("mods:", dump(modifiers))
   assert(
      _iter(modifiers):count() <= 1,
      "cannot use multiple (" ..
         tostring(_iter(modifiers):count()) .. ") modifiers at the same time, in: `" .. pattern[1].meta.source .. "`"
   )

   if modifiers["*"] then
      local nodes = {}

      repeat
         if variant then
            dprint("\t=== variant", rule, variant)
            local pattern = segment[rule][variant] or findOrderedKey(segment[rule], variant)
            local iter = iter(collect(tokenize(pattern, {file = "template"})))
            node = parse(tokens, segment, rule, variant, iter)
         elseif rule then
            dprint("\t=== rule", rule)
            for variant, pattern in pairs(segment[rule]) do
               dprint("trying ", variant, pattern)
               local iter = iter(collect(tokenize(pattern, {file = "template"})))
               node = parse(tokens, segment, rule, variant, iter)
               dprint("??" .. dump(node))
               if node then
                  break
               end
            end
         else
            node = tokens:check(tokentype) and tokens:next().lexeme
         end
         nodes[#nodes + 1] = node
      until not node or not tokens:peek()

      return #nodes > 0 and {type = _type, unpack(nodes)}
   else
      if not rule and not tokentype then
         if tokens:match(node) then
            -- dprint("matched string '" .. node .. "'")
            return node
         -- else
         -- dprint("didn't match string '" .. node .. "'")
         end
      elseif rule then
         if variant then
            dprint("\t=== variant", rule, variant)
            local pattern = segment[rule][variant] or findOrderedKey(segment[rule], variant)
            local iter = iter(collect(tokenize(pattern, {file = "template"})))
            node = parse(tokens, segment, rule, variant, iter)
         else
            dprint("\t=== rule", rule)
            for variant, pattern in pairs(segment[rule]) do
               if type(pattern) == "table" then
                  variant, pattern = next(pattern)
               end
               -- dprint("?> trying ", variant, dump(pattern))
               local iter = iter(collect(tokenize(pattern, {file = "template"})))
               node = parse(tokens, segment, rule, variant, iter)
               -- dprint("??" .. dump(node))
               if node then
                  if type(variant) == "string" then
                     _type[#_type + 1] = variant
                  end
                  break
               end
            end
         end

         dprint("Noe", node)

         if node then
            return setmetatable(node, {type = _type})
         end
      elseif tokentype and tokens:check(tokentype) then
         dprint("matched tokentype " .. tokentype.T)
         return tokens:next().lexeme
      end
   end
end

-- pstring(pattern:table) -> string
function pstring(pattern)
   local str = ""
   -- unset ignores to capture everything

   if pattern:match "'" then
   --print('matched string begin')
   end
   local ignores = pattern.__iter__.skip
   pattern.__iter__.skip = {}

   local s = ""
   for i = -2, 2 do
      s = s .. (i == 0 and "\27[41m" or "") .. (pattern:get(i) or "") .. (i == 0 and "\27[0m" or "")
   end
   -- dprint("{" .. s .. "}")

   while not pattern:match "'" do
      assert(pattern:peek(), 'unclosed string "' .. str .. '"')
      if pattern:match("\\") then
         --dprint('string: matched escape')
         local sym = pattern:next().lexeme

         if sym:starts("n") then
            str = str .. "\n"
            str = str .. sym:sub(2)
         elseif sym:starts("t") then
            str = str .. "\t"
            str = str .. sym:sub(2)
         elseif sym:starts("0") then
            str = str .. "\0"
            str = str .. sym:sub(2)
         elseif sym:starts("e") then
            str = str .. "\27"
            str = str .. sym:sub(2)
         else
            str = str .. sym
         end
      else
         str = str .. pattern:next().lexeme
         -- dprint("<" .. str .. '> "' .. tostring(pattern:peek()) .. '"')
      end
   end

   -- reset ignores
   -- dprint("STRING<" .. str .. ">")
   local s = ""
   for i = -2, 2 do
      s = s .. (i == 0 and "\27[41m" or "") .. (pattern:get(i) or "") .. (i == 0 and "\27[0m" or "")
   end
   -- dprint("{" .. s .. "}")
   pattern.__iter__.skip = ignores
   --   pattern:next()
   return str
end

function synth(source, template)
   return process(iter(collect(tokenize(source))), temp)
end

print(synth("3 - 2 + 1 - 2 + 3", temp))
print(">> done")
-- tokenize("hello world hello me", {file='local'})
-- tokenize("1 + 2 * 4 / 5 * 6 + 7")
--[[
(1 + ((2 * 4) / 5) * 6)) + 7
]]
--    tokenize([[

-- ]])
